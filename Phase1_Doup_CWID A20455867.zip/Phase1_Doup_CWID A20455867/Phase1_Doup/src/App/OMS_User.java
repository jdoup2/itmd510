package App;

public class OMS_User{
	
	public int user_ID;
	public String oms_username;
	public String oms_password;	
}