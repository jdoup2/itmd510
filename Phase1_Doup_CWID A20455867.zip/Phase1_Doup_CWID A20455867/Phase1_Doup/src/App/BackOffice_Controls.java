package App;

public interface BackOffice_Controls {

	public void Transactions();
	public void Investor_Details();
	public void Investor_Changes();
	public void Investor_Balance();
	
}

