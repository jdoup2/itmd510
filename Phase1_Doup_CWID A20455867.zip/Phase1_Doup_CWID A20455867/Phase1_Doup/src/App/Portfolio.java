package App;

public class Portfolio {

	public String portfolioID;
	public String CounterPartyID;
	public long LongAmount;
	public long balance;
	
}

