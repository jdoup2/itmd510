package App;

public class PortfolioManager_Profile extends OMS_User implements AssetManagement_Controls {
	
	public int pmID;
	public String first_name;
	public String last_name;	
	public String position;
	public String office_city;
	public String office_state;
	public String office_postal_code;
	
	
	public int phone;
	public int account_number;
	
	
	public Allocation transaction;

	@Override
	public void Transactions() {
	
		
	}

	@Override
	public void SecurityReference() {
		
	}

	@Override
	public void buy() {
	
		
	}

	@Override
	public void sell() {
		
		
	}

	@Override
	public void deposit() {
		
		
	}

	@Override
	public void withdraw() {
		
		
	}

	@Override
	public void CustodianAccountDetailsAdd() {
		
		
	}

	@Override
	public void UpdateWireDetails() {
		
		
	}

	@Override
	public void AccountInfoEdit() {
		
		
	}
}