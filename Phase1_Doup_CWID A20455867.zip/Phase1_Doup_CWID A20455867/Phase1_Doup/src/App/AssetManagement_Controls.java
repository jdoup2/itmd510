package App;

public interface AssetManagement_Controls {
	
	public void buy();
	public void sell();
	public void deposit();
	public void withdraw();
	public void Transactions();
	public void AccountInfoEdit();	
	public void SecurityReference();
	public void CustodianAccountDetailsAdd();
	public void UpdateWireDetails();
	
	
}
