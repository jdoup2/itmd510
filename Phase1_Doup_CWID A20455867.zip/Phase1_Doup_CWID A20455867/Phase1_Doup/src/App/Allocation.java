package App;

public class Allocation {

	public int AllocationID;
	public double SecurityPrice;
	public Portfolio portfolio;
	
}