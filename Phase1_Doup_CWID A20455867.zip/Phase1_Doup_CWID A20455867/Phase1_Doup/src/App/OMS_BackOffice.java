package App;

public class OMS_BackOffice extends OMS_User implements BackOffice_Controls {

	public String BackOffice_ID;
	public String First_Name;
	public String Last_Name;
	public String Position;
	@Override
	public void Transactions() {
		
		
	}
	@Override
	public void Investor_Details() {
		
		
	}
	@Override
	public void Investor_Balance() {
		
		
	}
	@Override
	public void Investor_Changes() {
		
		
	}
}

